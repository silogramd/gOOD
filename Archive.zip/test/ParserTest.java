import static org.junit.Assert.*;

import edu.cs3500.spreadsheets.sexp.Parser;
import java.util.Scanner;
import org.junit.Test;

public class ParserTest {

  @Test
  public void parse() {

    System.out.println(Parser.parse("(SUM (PRODUCT A1 B1) 2)"));





  }
}