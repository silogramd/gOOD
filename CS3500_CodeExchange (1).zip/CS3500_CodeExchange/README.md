# Spreadsheet

Visual View 
- Displays a spreadsheet with scrollbars that allow for infinite scrolling

Editor View 
- Displays a spreadsheet with scrollbars that allow for infinite scrolling
- A text field that allows for editing cells
- A accept and deny field for updating the spreadsheet
- Mouse selection for the cell
- Backspace/delet to clear cell
- Save and upload buttons to save and open spreadsheets
- Arrow keys to change selected cell
