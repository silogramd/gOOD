package edu.cs3500.spreadsheets.view;

import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.io.IOException;

import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.ViewWorksheet;

/**
 * Interface for the visual worksheets with methods needed to create, update, and interact with the
 * view.
 */
public interface WorksheetView {
  /**
   * Opens the visual view so it is visual to the user.
   */
  void render() throws IOException;
  
  /**
   * Updates the current view.
   */
  void refresh();
  
  //  /**
  //   * Sets the action listeners for the visual view.
  //   */
  //  void addFeatures(Features featuresListener);
  
  /**
   * adds a mouse listener.
   */
  void addMouseListener(MouseListener ml);
  
  /**
   * adds an action listener.
   */
  void addActionListener(ActionListener actionListener);
  
  /**
   * adds a key lisetener.
   */
  void addKeyListener(KeyListener kl);
  
  /**
   * Highlights a certain given cell.
   *
   * @param c Coord object with cell coordinates
   */
  void highlightCell(Coord c, String rawData);
  
  /**
   * moves the x value.
   */
  void moveX(int i);
  
  /**
   * move the y value.
   */
  void moveY(int i);
  
  /**
   * reset this focus.
   */
  void resetFocus();
  
  /**
   * selects a certain cell.
   */
  Coord selectCell(int x, int y);
  
  /**
   * get the input for the textfield.
   */
  String getInput();
  
  /**
   * set the text.
   */
  void setText(String s);
  
  /**
   * set the model of this view.
   */
  void setModel(ViewWorksheet model);
  
  /**
   * open a file.
   */
  String getOpenFile();
  
  /**
   * save the file.
   */
  String getSaveFile();
}
