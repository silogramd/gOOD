package edu.cs3500.spreadsheets.view;

import java.awt.event.ActionListener;

//import edu.cs3500.spreadsheets.controller.Features;
import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.ViewWorksheet;

/**
 * interface for the worksheetPane for certain user instantiated features.
 */
public interface WorksheetPane {
  Coord getTopLeft();
  
  void moveX(int x);
  
  void moveY(int y);
  
  void highlightCell(Coord c);
  //void addFeatures(Features f);
  
  /**
   * select a certain coord.
   */
  Coord selectCell(int x, int y);
  
  /**
   * adds the action listener.
   */
  void addActionListener(ActionListener actionListener);
  
  /**
   * set the model to this model.
   */
  void setModel(ViewWorksheet model);
  
  //void addKeyListener(KeyListener kl);
  
}
