package edu.cs3500.spreadsheets.view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.JScrollBar;

import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.ViewWorksheet;

/**
 * Scrollable worksheet view.
 */
class ScrollableWorksheet extends JPanel implements WorksheetPane {
  private WorksheetPanel worksheetPanel;
  
  /**
   * constructor for scrollable worksheet.
   */
  ScrollableWorksheet(ViewWorksheet model) {
    WorksheetPanel.WorksheetPanelBuilder builder = new WorksheetPanel.WorksheetPanelBuilder();
    builder.setModel(model);
    
    this.worksheetPanel = builder.buildWorksheet();
    //this.values = model.getAllValues();
    //Coord topLeftCoord = new Coord(1, 1);
    JScrollBar vertical = new JScrollBar(JScrollBar.VERTICAL, 1, 100, 1, 600);
    JScrollBar horizontal = new JScrollBar(JScrollBar.HORIZONTAL, 1, 100, 1, 600);
    vertical.addAdjustmentListener(worksheetPanel);
    horizontal.addAdjustmentListener(worksheetPanel);
    GridBagConstraints gbc = new GridBagConstraints();
    setLayout(new GridBagLayout());
    
    gbc.anchor = GridBagConstraints.PAGE_START;
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.weightx = .5;
    gbc.weighty = .5;
    gbc.fill = GridBagConstraints.BOTH;
    add(this.worksheetPanel, gbc);
    
    gbc.gridx = 1;
    gbc.gridy = 0;
    gbc.weightx = 0;
    gbc.weighty = 1;
    gbc.fill = GridBagConstraints.VERTICAL;
    add(vertical, gbc);
    
    gbc.gridx = 0;
    gbc.gridy = 1;
    gbc.weightx = 1;
    gbc.weighty = 0;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    add(horizontal, gbc);
    
  }
  
  /**
   * gets the top left cell of the panel.
   */
  @Override
  public Coord getTopLeft() {
    return this.worksheetPanel.getTopLeft();
  }
  
  /**
   * moves the x value.
   */
  @Override
  public void moveX(int x) {
    return;
  }
  
  /**
   * moces the y values.
   */
  @Override
  public void moveY(int y) {
    return;
  }
  
  /**
   * highlight a certain cell.
   */
  @Override
  public void highlightCell(Coord c) {
    this.worksheetPanel.highlightCell(c);
  }
  //
  //  @Override
  //  public void addFeatures(Features f) {
  //
  //  }
  
  /**
   * select a certain cell using the x and y.
   */
  @Override
  public Coord selectCell(int x, int y) {
    return this.worksheetPanel.selectCell(x, y);
  }
  
  /**
   * sets the action listener.
   */
  @Override
  public void addActionListener(ActionListener actionListener) {
    return;
  }
  
  /**
   * sets the model of the view.
   */
  @Override
  public void setModel(ViewWorksheet model) {
    this.worksheetPanel.setModel(model);
  }
  //
  //  @Override
  //  public void addKeyListener(KeyListener kl) {
  //    this.worksheetPanel.addKeyListener(kl);
  //  }
  
  
}